package Dx_ET_Trade.ET_Trade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EtTradeApplication {

	public static void main(String[] args) {
		SpringApplication.run(EtTradeApplication.class, args);
	}

}
