package Dx_ET_Trade.ET_Trade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EtTradeApplicationTests {

	@Test
	void contextLoads() {
	}

}
